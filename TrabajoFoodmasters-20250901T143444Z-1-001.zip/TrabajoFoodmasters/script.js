document.getElementById("Registrar").addEventListener("click", (e) => {
    e.preventDefault();
    const NomUsuario = document.getElementById("ObtUsuario").value;
    const Contraseña = document.getElementById("ObtContraseña").value;
    const Correo = document.getElementById("ObtCorreo").value;
    if (NomUsuario && Contraseña && Correo) {
        fetch("Registarse.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "nombre=" + encodeURIComponent(NomUsuario) + "&contraseña=" + encodeURIComponent(Contraseña) + "&correo=" + encodeURIComponent(Correo)
        }) //GET
            .then(res => res.json())
            .then(res => {
                if (res.error) {
                    console.error(res.error + ": " + res.msj);
                } else {
                    console.log(res.msj);
                }
            
        });
        }
         else {
        console.log("Completa los campos");
    }
});