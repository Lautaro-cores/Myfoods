<?php
$server = "localhost";
$user = "root";
$pass = "";
$bd = "foodmasters";

$con = mysqli_connect($server, $user, $pass, $bd);